/*
  PERSONALIZAÇÃO
  ============================
  Os dados da festa ficam aqui.
*/
const EVENT = {
  name: "Nilda Sunset",
  dateISO: "2026-10-10",
  dateLabel: "10 de outubro",
  time: "15h30",
  location: "Studio29",
  address: "Rua Santa Isabel, 29 · Barro Duro · Maceió, AL · 57045-310",

  // Número que receberá as confirmações.
  whatsapp: "5582998386476",

  // Número máximo de acompanhantes no formulário.
  maxCompanions: 5,

  mapUrl: "https://www.google.com/maps/place/Studio29+-+Festas+e+Eventos/@-9.6201872,-35.7201473,17z/data=!4m6!3m5!1s0x70147a68d86d84f:0x18915ba332182bb1!8m2!3d-9.6201872!4d-35.7201473!16s%2Fg%2F11wn029h_q?entry=ttu"
};

const $ = (s) => document.querySelector(s);

$("#eventName").textContent = EVENT.name.replace(/^Nilda\s*/i, "").toLowerCase();
$("#maxCompanionsLabel").textContent = EVENT.maxCompanions;

let companionCount = 0;

function showError(text) {
  const el = $("#formError");
  el.textContent = text;
  el.classList.remove("hidden");
}

function clearError() {
  const el = $("#formError");
  el.textContent = "";
  el.classList.add("hidden");
}

function renderCompanions() {
  $("#companionCount").textContent = companionCount;
  $("#companionsWrap").classList.toggle("hidden", companionCount === 0);

  const list = $("#companionsList");
  list.innerHTML = "";

  for (let i = 1; i <= companionCount; i++) {
    const row = document.createElement("div");
    row.className = "companion-card";
    row.innerHTML = `
      <label for="companion-${i}" class="input-label !mt-0">Acompanhante ${i}</label>
      <input
        id="companion-${i}"
        class="input"
        type="text"
        placeholder="Nome completo"
        autocomplete="off"
        required
      >
    `;
    list.appendChild(row);
  }
}

$("#minusBtn").addEventListener("click", () => {
  if (companionCount > 0) {
    companionCount--;
    clearError();
    renderCompanions();
  }
});

$("#plusBtn").addEventListener("click", () => {
  if (companionCount < EVENT.maxCompanions) {
    companionCount++;
    clearError();
    renderCompanions();
  } else {
    showError(`O máximo é de ${EVENT.maxCompanions} acompanhantes.`);
  }
});

$("#rsvpForm").addEventListener("submit", (e) => {
  e.preventDefault();
  clearError();

  const guestName = $("#guestName").value.trim();

  if (!guestName) {
    showError("Digite seu nome.");
    $("#guestName").focus();
    return;
  }

  const companions = [...document.querySelectorAll("#companionsList input")]
    .map(input => input.value.trim());

  if (companions.some(Boolean) === false && companionCount > 0) {
    showError("Preencha o nome dos acompanhantes.");
    return;
  }

  if (companions.some(name => !name)) {
    showError("Preencha o nome de todos os acompanhantes.");
    const empty = [...document.querySelectorAll("#companionsList input")]
      .find(input => !input.value.trim());
    empty?.focus();
    return;
  }

  let companionPart = "e não levarei acompanhantes";

  if (companions.length === 1) {
    companionPart = `e levarei como acompanhante ${companions[0]}`;
  } else if (companions.length > 1) {
    companionPart = `e levarei como acompanhantes ${formatNames(companions)}`;
  }

  const message =
    `Eu, ${guestName}, confirmo minha presença no ${EVENT.name} ${companionPart}.`;

  const url =
    `https://wa.me/${EVENT.whatsapp}?text=${encodeURIComponent(message)}`;

  window.location.href = url;
});

function formatNames(names) {
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} e ${names[1]}`;
  return `${names.slice(0, -1).join(", ")} e ${names[names.length - 1]}`;
}

renderCompanions();
